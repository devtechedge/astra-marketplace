import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'jsdom',
    globals: true,
    include: ['tests/unit/**/*.test.ts']
  },
  resolve: {
    alias: { '@': new URL('./src', import.meta.url).pathname }
  }
});
